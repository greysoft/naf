package greytest;
public class DynTest3 {
	public static void main(String[] args) {
		System.out.println("This is DynTest - "+DynTest3.class.getName());
	}
}
