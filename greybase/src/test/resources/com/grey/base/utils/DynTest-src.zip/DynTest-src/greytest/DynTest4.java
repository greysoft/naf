package greytest;
public class DynTest4 {
	public static void main(String[] args) {
		System.out.println("This is DynTest - "+DynTest4.class.getName());
	}
}
