package greytest;
public class DynTest2 {
	public static void main(String[] args) {
		System.out.println("This is DynTest - "+DynTest2.class.getName());
	}
}
