# Sample run command: java -cp DynTest1.jar greytest.DynTest1
rm -f greytest/*.class *.jar
javac greytest/*.java
jar cvf DynTest1.jar greytest/*1.class
jar cvf DynTest2.jar greytest/*2.class
jar cvf DynTest3.jar greytest/*3.class
jar cvf DynTest4.jar greytest/*4.class
