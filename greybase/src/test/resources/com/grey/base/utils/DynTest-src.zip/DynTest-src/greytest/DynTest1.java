package greytest;
public class DynTest1 {
	public static void main(String[] args) {
		System.out.println("This is DynTest - "+DynTest1.class.getName());
	}
}
